public abstract class Character {
    private int hitPoints;
    private int armorClass;

    protected Character(int hitPoints, int armorClass) {
        this.hitPoints = hitPoints;
        this.armorClass = armorClass;
    }

    public abstract void wearArmor();

    public abstract void useWeapon();

    public String toString() {
        return  "\nI have " + this.hitPoints + " HPs and " + this.armorClass + " AC" ;
    }
}
