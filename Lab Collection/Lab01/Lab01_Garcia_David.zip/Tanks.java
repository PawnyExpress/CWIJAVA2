public abstract class Tanks extends Character {

    protected Tanks(int hitPoints, int armorClass) {
        super(hitPoints, armorClass);
    }

    public void wearArmor() {
        System.out.println("I wear ");
    }

    public void useWeapon() {
        System.out.println("I wield ");
    }
    
}
